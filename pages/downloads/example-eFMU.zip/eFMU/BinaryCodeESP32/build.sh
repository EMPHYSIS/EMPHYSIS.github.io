cd /mnt/e
cd dev/git/efmi-test-cases/eFMUs/BinCode/ESP/from_ESP/from_Dymola/M04_A/eFMU/BinaryCodeESP32
make
