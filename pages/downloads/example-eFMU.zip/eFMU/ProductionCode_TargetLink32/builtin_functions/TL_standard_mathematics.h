/*
 * Copyright (C) 2021 dSPACE GmbH, All rights reserved.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND.
 */

#ifndef STANDARD_MATHEMATICS_H
#define STANDARD_MATHEMATICS_H

#include "TL_primitive_types.h"

#include <math.h>


#define dstl_map_int_result_to_bool(arg) (0 == (arg) ? dstl_Boolean_False : dstl_Boolean_True)

#define dstl_isNaN(arg) dstl_map_int_result_to_bool(isnan(arg))

#define dstl_isInfinite(arg) dstl_map_int_result_to_bool(isinf(arg))


/* Not part of spec but needed if ^ operator is not mapped to multiplication */
#if REAL_IS_SINGLE_INSTEAD_OF_DOUBLE != 0
#   define dstl_pow(base, exponent) powf(base, exponent)
#else
#   define dstl_pow(base, exponent) pow(base, exponent)
#endif


#endif /* STANDARD_MATHEMATICS_H */
