/*
 * Copyright (C) 2021 dSPACE GmbH, All rights reserved.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND.
 */

#include "TL_error_signals.h"

/* --- global functions --- */

dstl_Boolean dstl_test_error_signals(dstl_ErrorSignalStatusType mask,
                                        dstl_ErrorSignalStatusType* pErrorSignalStatus)
{
    if ((*pErrorSignalStatus & mask) == mask)
    {
        /* All given signals are set
         * => Return true and unset those signals.
         */
        dstl_ErrorSignalStatusType inverse_mask = ~mask;
        *pErrorSignalStatus &= inverse_mask;
        return dstl_Boolean_True;
    }
    else
    {
        /* At least one signal is not set
         * => Return false and do NOT change the signal status word
         */
        return dstl_Boolean_False;
    }
}
