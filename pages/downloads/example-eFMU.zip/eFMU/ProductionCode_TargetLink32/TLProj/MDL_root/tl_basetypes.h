/**************************************************************************************************\
 *** 
 *** Codefile             : tl_basetypes.h
 ***
 *** Generation date: 2021-03-08 10:44:59 by TargetLink, the dSPACE production quality code generator
 ***
 *** Copyright (C) 2021 dSPACE GmbH, All rights reserved.
 ***
 *** THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND.
 ***
\**************************************************************************************************/

#ifndef TL_BASETYPES_H
#define TL_BASETYPES_H

#include <stdint.h>

typedef _Bool Bool; /* Description: boolean basetype */
typedef float Float32; /* Description: 32 bit floating-point basetype */
typedef double Float64; /* Description: 64 bit floating-point basetype */
typedef int16_t Int16; /* Description: 16 bit signed integer basetype */
typedef int32_t Int32; /* Description: 32 bit signed integer basetype */
typedef int64_t Int64; /* Description: 64 bit signed integer basetype */
typedef int8_t Int8; /* Description: 8 bit signed integer basetype */
typedef uint16_t UInt16; /* Description: 16 bit unsigned integer basetype */
typedef uint32_t UInt32; /* Description: 32 bit unsigned integer basetype */
typedef uint64_t UInt64; /* Description: 64 bit unsigned integer basetype */
typedef uint8_t UInt8; /* Description: 8 bit unsigned integer basetype */

#endif /* TL_BASETYPES_H */
/*------------------------------------------------------------------------------------------------*\
  END OF FILE
\*------------------------------------------------------------------------------------------------*/
