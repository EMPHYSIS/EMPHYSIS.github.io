/*
 * Copyright (C) 2021 dSPACE GmbH, All rights reserved.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND.
 */

#ifndef SATURATION_H
#define SATURATION_H

#include "TL_primitive_types.h"


#define dstl_IntegerSATb(value, losatval, upsatval)\
    dstl_SaturateB(value, losatval, upsatval)
#define dstl_IntegerSATu(value, upsatval)\
    dstl_SaturateU(value, upsatval)
#define dstl_IntegerSATl(value, losatval)\
    dstl_SaturateL(value, losatval)

#define dstl_RealSATb(value, losatval, upsatval)\
    dstl_SaturateB(value, losatval, upsatval)
#define dstl_RealSATu(value, upsatval)\
    dstl_SaturateU(value, upsatval)
#define dstl_RealSATl(value, losatval)\
    dstl_SaturateL(value, losatval)


/* The following macros should NOT be called directly.
 * They are used by the above ones.
 */

#define dstl_SaturateB(value, losatval, upsatval)\
    ( ((value) > (upsatval)) ? (upsatval) : ( ((value) < (losatval)) ? (losatval) : (value) ) )
#define dstl_SaturateU(value, upsatval)\
    ( ((value) > (upsatval)) ? (upsatval) : (value) )
#define dstl_SaturateL(value, losatval)\
    ( ((value) < (losatval)) ? (losatval) : (value) )


#endif /* SATURATION_H */
