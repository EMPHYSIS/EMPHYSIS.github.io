/*
 * Copyright (C) 2021 dSPACE GmbH, All rights reserved.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND.
 */

#ifndef ERROR_SIGNALS_H
#define ERROR_SIGNALS_H

#include "TL_primitive_types.h"


/* - Error signals - */

/* Predefined error signals */

#define eFMU_err_INVALID_ARGUMENT ((UInt32) 1)
#define eFMU_err_OVERFLOW ((UInt32) 2)
#define eFMU_err_NAN ((UInt32) 4)
#define eFMU_err_SOLVE_LINEAR_EQUATIONS_FAILED ((UInt32) 8)
#define eFMU_err_NO_SOLUTION_FOUND ((UInt32) 16)
#define eFMU_err_UNSPECIFIED_ERROR ((UInt32) 32)

#define eFMU_err_all_predefined_signals (eFMU_err_INVALID_ARGUMENT | eFMU_err_OVERFLOW | eFMU_err_NAN | eFMU_err_SOLVE_LINEAR_EQUATIONS_FAILED | eFMU_err_NO_SOLUTION_FOUND | eFMU_err_UNSPECIFIED_ERROR)


/* Builtin functions to test/set signals */

extern dstl_Boolean dstl_test_error_signals(dstl_ErrorSignalStatusType mask,
                                          dstl_ErrorSignalStatusType* pErrorSignalStatus);

#define dstl_set_error_signals(mask, pErrorSignalStatus) *(pErrorSignalStatus) |= (mask);


#endif /* ERROR_SIGNALS_H */
