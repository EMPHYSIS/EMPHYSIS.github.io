/*
 * Copyright (C) 2021 dSPACE GmbH, All rights reserved.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND.
 */

#ifndef PRIMITIVE_TYPES_H
#define PRIMITIVE_TYPES_H

#include "tl_basetypes.h"

#include "TL_float_precision.h"

/* For FLT_EPSILON + DBL_EPSILON */
#include <float.h>

/* For C99 stuff like NaN */
#include <math.h>


/* - Boolean - */

#define dstl_Boolean Bool
#define dstl_Boolean_True ((dstl_Boolean)1)
#define dstl_Boolean_False ((dstl_Boolean)0)


/* - Integer - */

#define dstl_Integer Int32


/* Defined according to property in code generation */
#define dstl_Size Int32

#define dstl_UnsignedInteger UInt32
#define dstl_SignedInteger Int32

#define dstl_ErrorSignalStatusType UInt32


/* - Real - */

#undef FLT_DBL_EPSILON

#if REAL_IS_SINGLE_INSTEAD_OF_DOUBLE != 0
#   define dstl_Real Float32
#   define FLT_DBL_EPSILON FLT_EPSILON
#   define FLT_DBL_CONST_ONE 1.0f
#   define FLT_DBL_CONST_ZERO 0.0f
#   define FLT_DBL_CONST_POINT_FIVE 0.5f
#   define FLT_DBL_CONST_TWO 2.0f
/* PI is not defined in the C standard, only POSIX as M_PI, which is always double */
#   define FLT_DBL_CONST_PI (FLT_DBL_CONST_TWO * asinf(FLT_DBL_CONST_ONE))
#else
#   define dstl_Real Float64
#   define FLT_DBL_EPSILON DBL_EPSILON
#   define FLT_DBL_CONST_ONE 1.0
#   define FLT_DBL_CONST_ZERO 0.0
#   define FLT_DBL_CONST_POINT_FIVE 0.5
#   define FLT_DBL_CONST_TWO 2.0
/* see above */
#   define FLT_DBL_CONST_PI (FLT_DBL_CONST_TWO * asin(FLT_DBL_CONST_ONE))
#endif


#define FLT_DBL_INFINITY ((dstl_Real)INFINITY)

/* The "NAN" macro of C99 represents a quiet NaN. */
#define FLT_DBL_NAN ((dstl_Real)NAN)


#endif /* PRIMITIVE_TYPES_H */
