#ifndef M04_A_H
#define M04_A_H
/**
 * @warning   AUTOMATICALLY GENERATED FILE! DO NOT EDIT!
 * @warning   THIS IS A NIGHTLY TOOL BUILD! DO NOT USE FOR PRODUCTION!
 * 
 * @source    'eFMI_TestCases.M04_DrivetrainTorqueControl.Controllers.Controller'
 * 
 * @tool      SCODE-CONGRA (EFMI)  Build Id: 0000
 * 
 * @date      3/15/2021 08:20:42 AM
 * 
 **/
#include <math.h>
extern unsigned int signalVariable;
/* Range: [-1000000.0, 1000000.0] */
extern float M_desired;
/* Range: [-10000.0, 10000.0] */
extern float wRel;
/* Range: [-1000000.0, 1000000.0] */
extern float M_motor;
/* Range: (-oo, oo) */
extern float J_M;
/* Range: [1.0E-13, oo) */
extern float Ni_PI;
/* Range: [1.0E-60, oo) */
extern float Ti_PI;
/* Range: [0.0, oo) */
extern float c_res;
/* Range: [0.0, oo) */
extern float d_res;
/* Range: (-oo, oo) */
extern float f_cut;
/* Range: (-oo, oo) */
extern float gearRatio;
/* Range: (-oo, oo) */
extern float k_PI;
/* Range: (-oo, oo) */
extern float k_accCor;
/* Range: (-oo, oo) */
extern float tauM_max;

void Recalibrate(void);

void DoStep(float M_desired, float wRel, float * M_motor, unsigned int * signalVariable);

void Startup(unsigned int * signalVariable);

#endif  /* M04_A_H */
