/**
 * @warning   AUTOMATICALLY GENERATED FILE! DO NOT EDIT!
 * @warning   THIS IS A NIGHTLY TOOL BUILD! DO NOT USE FOR PRODUCTION!
 * 
 * @source    'eFMI_TestCases.M04_DrivetrainTorqueControl.Controllers.Controller'
 * 
 * @tool      SCODE-CONGRA (EFMI)  Build Id: 0000
 * 
 * @date      3/15/2021 08:20:42 AM
 * 
 **/
#include "M04_A.h"
#include <math.h>
unsigned int signalVariable = 0U;
/* Range: [-1000000.0, 1000000.0] */
float M_desired = 0.0F;
/* Range: [-10000.0, 10000.0] */
float wRel = 0.0F;
/* Range: [-1000000.0, 1000000.0] */
float M_motor = 0.0F;
/* Range: (-oo, oo) */
float J_M = 0.01F;
/* Range: [1.0E-13, oo) */
float Ni_PI = 1.34F;
/* Range: [1.0E-60, oo) */
float Ti_PI = 1.25F;
/* Range: [0.0, oo) */
float c_res = 4710.0F;
/* Range: [0.0, oo) */
float d_res = 1.57F;
/* Range: (-oo, oo) */
float f_cut = 33.0F;
/* Range: (-oo, oo) */
float gearRatio = 10.0F;
/* Range: (-oo, oo) */
float k_PI = -73.0F;
/* Range: (-oo, oo) */
float k_accCor = -0.010161522F;
/* Range: (-oo, oo) */
float tauM_max = 1230.0F;
/* Range: (-oo, oo) */
static float PI_yMin = -1230.0F;
/* Range: (-oo, oo) */
static float PI_y = 0.0F;
/* Range: (-oo, oo) */
static float PI_I_k = 0.8F;
/* Range: (-oo, oo) */
static float derivative_PI_I_y_ = 0.0F;
/* Range: (-oo, oo) */
static float PI_I_u = 0.0F;
/* Range: [-10000.0, 10000.0] */
static float PI_I_y = 0.0F;
/* Range: (-oo, oo) */
static float PI_P_y = 0.0F;
/* Range: (-oo, oo) */
static float PI_addI_u3 = 0.0F;
/* Range: (-oo, oo) */
static float PI_addP_y = 0.0F;
/* Range: (-oo, oo) */
static float PI_addSat_y = 0.0F;
/* Range: (-oo, oo) */
static float PI_gainPI_u = 0.0F;
/* Range: (-oo, oo) */
static float PI_gainPI_y = 0.0F;
/* Range: (-oo, oo) */
static float PI_gainTrack_k = -0.010222859F;
/* Range: (-oo, oo) */
static float PI_limiter_u = 0.0F;
/* Range: [0.0, oo) */
static float approxPlant_driveline_J_M = 1.0E-4F;
/* Range: (-oo, oo) */
static float derivative_approxPlant_driveline_Gear_phi_rel_ = 0.0F;
/* Range: (-oo, oo) */
static float derivative_approxPlant_driveline_Gear_tau_c_ = 0.0F;
/* Range: (-oo, oo) */
static float derivative_approxPlant_driveline_Gear_tau_d_ = 0.0F;
/* Range: (-oo, oo) */
static float derivative_approxPlant_driveline_Gear_w_rel_ = 0.0F;
/* Range: (-oo, oo) */
static float approxPlant_driveline_Gear_phi_rel = 0.0F;
/* Range: (-oo, oo) */
static float approxPlant_driveline_Gear_tau_c = 0.0F;
/* Range: (-oo, oo) */
static float approxPlant_driveline_Gear_tau_d = 0.0F;
/* Range: (-oo, oo) */
static float derivative_approxPlant_driveline_flange_b_tau_ = 0.0F;
/* Range: (-oo, oo) */
static float approxPlant_driveline_flange_b_tau = 0.0F;
/* Range: (-oo, oo) */
static float derivative_approxPlant_driveline_inertiaDrivelineIn_w_ = 0.0F;
/* Range: (-oo, oo) */
static float approxPlant_driveline_inertiaDrivelineIn_flange_b_tau = 0.0F;
/* Range: (-oo, oo) */
static float derivative_approxPlant_torqueDist_flange_tau_ = 0.0F;
/* Range: (-oo, oo) */
static float approxPlant_torqueDist_flange_tau = 0.0F;
/* Range: (-oo, oo) */
static float filter_alpha = 0.64359426F;
/* Range: (-oo, oo) */
static float filter_w = 322.16745F;
/* Range: (-oo, oo) */
static float derivative_filter_x_1__ = 0.0F;
/* Range: (-oo, oo) */
static float derivative_filter_x_2__ = 0.0F;
/* Range: (-oo, oo) */
static float filter_x_1_ = 0.0F;
/* Range: (-oo, oo) */
static float filter_x_2_ = 0.0F;
/* Range: (-oo, oo) */
static float gear_u = 0.0F;
/* Range: (-oo, oo) */
static float gear_y = 0.0F;
/* Range: (-oo, oo) */
static float gear1_k = 0.1F;

void Recalibrate(void) {
	/* Recalibration function for dependent parameter */
	/* (258): self.'PI.yMin' := -(self.tauM_max) */
	PI_yMin = -tauM_max;
	/* (259): self.'PI.I.k' := (1.0 / self.Ti_PI) */
	PI_I_k = 1.0F / Ti_PI;
	/* (260): self.'PI.gainTrack.k' := (1.0 / (self.k_PI * self.Ni_PI)) */
	PI_gainTrack_k = 1.0F / (k_PI * Ni_PI);
	/* (261): self.'gear1.k' := (1.0 / self.gearRatio) */
	gear1_k = 1.0F / gearRatio;
	/* (262): self.'filter.alpha' := (if self.'filter.normalized' then 6.43594252905582698E-01 else 1.0) */
	filter_alpha = 0.64359426F;
	/* (263): self.'filter.w' := ((6.28318530717958623 * self.f_cut) / self.'filter.alpha') */
	filter_w = 6.2831855F * f_cut / filter_alpha;
	/* (264): self.'approxPlant.driveline.J_M' := (self.J_M / (self.gearRatio * self.gearRatio)) */
	/* Attention: assignment out of defined range: [0.0, oo) is assigned a value from range:  (-oo, oo) */
	approxPlant_driveline_J_M = J_M / (gearRatio * gearRatio);
	/* Adding saturation of limited variables when needed */
	/* Limitation needed for 'approxPlant.driveline.J_M'  with defined range: [0.0, oo) and current value range (-oo, oo) */
	if (approxPlant_driveline_J_M < 0.0F) {
		approxPlant_driveline_J_M = 0.0F;
	}
}	/* Recalibrate*/

void DoStep(float M_desired, float wRel, float * M_motor, unsigned int * signalVariable) {
	/* Range: (-oo, oo) */
	float solution_buffer_for_x;
	/* Adding pessimistic code against wrong use of function disregarding value ranges */
	/* Limitation needed for M_desired  with defined range: [-1000000.0, 1000000.0] and current value range (-oo, oo) */
	if (M_desired < -1000000.0F) {
		M_desired = -1000000.0F;
	} else if (M_desired > 1000000.0F) {
		M_desired = 1000000.0F;
	} else {
		/* limiting not needed */
	}
	/* Limitation needed for wRel  with defined range: [-10000.0, 10000.0] and current value range (-oo, oo) */
	if (wRel < -10000.0F) {
		wRel = -10000.0F;
	} else if (wRel > 10000.0F) {
		wRel = 10000.0F;
	} else {
		/* limiting not needed */
	}
	/* (280): self.'filter.x[2]' := (self.'filter.x[2]' + (self.'discrete.stepSize' * self.'derivative(filter.x[2])')) */
	filter_x_2_ = filter_x_2_ + (5.0E-4F * derivative_filter_x_2__);
	/* (281): self.'approxPlant.driveline.Gear.phi_rel' := (self.'approxPlant.driveline.Gear.phi_rel' + (self.'discrete.stepSize' * self.'derivative(approxPlant.driveline.Gear.phi_rel)')) */
	approxPlant_driveline_Gear_phi_rel = approxPlant_driveline_Gear_phi_rel + (5.0E-4F *
		 derivative_approxPlant_driveline_Gear_phi_rel_);
	/* (282): self.'filter.x[1]' := (self.'filter.x[1]' + (self.'discrete.stepSize' * self.'derivative(filter.x[1])')) */
	filter_x_1_ = filter_x_1_ + (5.0E-4F * derivative_filter_x_1__);
	/* (283): self.'PI.I.y' := (self.'PI.I.y' + (self.'discrete.stepSize' * self.'derivative(PI.I.y)')) */
	/* Attention: assignment out of defined range: [-10000.0, 10000.0] is assigned a value from range:  (-oo, oo) */
	PI_I_y = PI_I_y + (5.0E-4F * derivative_PI_I_y_);
	/* (286): self.'derivative(filter.x[2])' := ((self.'filter.x[1]' - self.'filter.x[2]') * self.'filter.w') */
	derivative_filter_x_2__ = (filter_x_1_ - filter_x_2_) * filter_w;
	/* (287): self.'derivative(approxPlant.torqueDist.flange.tau)' := -((self.k_accCor * self.'derivative(filter.x[2])')) */
	derivative_approxPlant_torqueDist_flange_tau_ = -(k_accCor * derivative_filter_x_2__);
	/* (288): self.'derivative(approxPlant.driveline.flange_b.tau)' := -((self.'derivative(filter.x[2])' + self.'derivative(approxPlant.torqueDist.flange.tau)')) */
	derivative_approxPlant_driveline_flange_b_tau_ = -(derivative_filter_x_2__ +
		 derivative_approxPlant_torqueDist_flange_tau_);
	/* (289): self.'approxPlant.torqueDist.flange.tau' := -((self.k_accCor * self.'filter.x[2]')) */
	approxPlant_torqueDist_flange_tau = -(k_accCor * filter_x_2_);
	/* (290): self.'approxPlant.driveline.flange_b.tau' := -((self.'filter.x[2]' + self.'approxPlant.torqueDist.flange.tau')) */
	approxPlant_driveline_flange_b_tau = -(filter_x_2_ + approxPlant_torqueDist_flange_tau);
	/* (291): self.'approxPlant.driveline.Gear.tau_c' := (self.c_res * (self.'approxPlant.driveline.Gear.phi_rel' - self.'approxPlant.driveline.Gear.phi_rel0')) */
	approxPlant_driveline_Gear_tau_c = c_res * (approxPlant_driveline_Gear_phi_rel - 0.0F);
	/* (292): self.'approxPlant.driveline.Gear.tau_d' := (self.'approxPlant.driveline.flange_b.tau' - self.'approxPlant.driveline.Gear.tau_c') */
	approxPlant_driveline_Gear_tau_d = approxPlant_driveline_flange_b_tau - approxPlant_driveline_Gear_tau_c;
	/* (293): 'solution_buffer.for.x' := (self.'approxPlant.driveline.Gear.tau_d' / self.d_res) */
	solution_buffer_for_x = approxPlant_driveline_Gear_tau_d / d_res;
	/* (294): if isNaN('solution_buffer.for.x') or isInfinite('solution_buffer.for.x')  */
	if (isnan(solution_buffer_for_x) || isinf(solution_buffer_for_x)) {
		/* (296): signal SOLVE_LINEAR_EQUATIONS_FAILED */
		*signalVariable = *signalVariable | 0x8U;
	} else {
		/* (299): self.'derivative(approxPlant.driveline.Gear.phi_rel)' := 'solution_buffer.for.x' */
		derivative_approxPlant_driveline_Gear_phi_rel_ = solution_buffer_for_x;
	}
	/* (301): self.'derivative(approxPlant.driveline.Gear.tau_c)' := (self.c_res * self.'derivative(approxPlant.driveline.Gear.phi_rel)') */
	derivative_approxPlant_driveline_Gear_tau_c_ = c_res * derivative_approxPlant_driveline_Gear_phi_rel_;
	/* (302): self.'derivative(approxPlant.driveline.Gear.tau_d)' := (self.'derivative(approxPlant.driveline.flange_b.tau)' - self.'derivative(approxPlant.driveline.Gear.tau_c)') */
	derivative_approxPlant_driveline_Gear_tau_d_ = derivative_approxPlant_driveline_flange_b_tau_ -
		 derivative_approxPlant_driveline_Gear_tau_c_;
	/* (303): 'solution_buffer.for.x' := (self.'derivative(approxPlant.driveline.Gear.tau_d)' / self.d_res) */
	solution_buffer_for_x = derivative_approxPlant_driveline_Gear_tau_d_ / d_res;
	/* (304): if isNaN('solution_buffer.for.x') or isInfinite('solution_buffer.for.x')  */
	if (isnan(solution_buffer_for_x) || isinf(solution_buffer_for_x)) {
		/* (306): signal SOLVE_LINEAR_EQUATIONS_FAILED */
		*signalVariable = *signalVariable | 0x8U;
	} else {
		/* (309): self.'derivative(approxPlant.driveline.Gear.w_rel)' := 'solution_buffer.for.x' */
		derivative_approxPlant_driveline_Gear_w_rel_ = solution_buffer_for_x;
	}
	/* (311): self.'derivative(approxPlant.driveline.inertiaDrivelineIn.w)' := -((self.gearRatio * self.'derivative(approxPlant.driveline.Gear.w_rel)')) */
	derivative_approxPlant_driveline_inertiaDrivelineIn_w_ = -(gearRatio * derivative_approxPlant_driveline_Gear_w_rel_);
	/* (312): 'solution_buffer.for.x' := (self.'approxPlant.driveline.flange_b.tau' / self.gearRatio) */
	solution_buffer_for_x = approxPlant_driveline_flange_b_tau / gearRatio;
	/* (313): if isNaN('solution_buffer.for.x') or isInfinite('solution_buffer.for.x')  */
	if (isnan(solution_buffer_for_x) || isinf(solution_buffer_for_x)) {
		/* (315): signal SOLVE_LINEAR_EQUATIONS_FAILED */
		*signalVariable = *signalVariable | 0x8U;
	} else {
		/* (318): self.'approxPlant.driveline.inertiaDrivelineIn.flange_b.tau' := 'solution_buffer.for.x' */
		approxPlant_driveline_inertiaDrivelineIn_flange_b_tau = solution_buffer_for_x;
	}
	/* (320): self.'gear.u' := ((self.'approxPlant.driveline.J_M' * self.'derivative(approxPlant.driveline.inertiaDrivelineIn.w)') - self.'approxPlant.driveline.inertiaDrivelineIn.flange_b.tau') */
	gear_u = (approxPlant_driveline_J_M * derivative_approxPlant_driveline_inertiaDrivelineIn_w_) -
		 approxPlant_driveline_inertiaDrivelineIn_flange_b_tau;
	/* (321): self.'gear.y' := (self.gearRatio * self.'gear.u') */
	gear_y = gearRatio * gear_u;
	/* (324): self.'PI.addP.y' := ((self.'PI.wp' * self.'derivative(approxPlant.driveline.Gear.phi_rel)') + (self.'PI.addP.k2' * self.wRel)) */
	PI_addP_y = derivative_approxPlant_driveline_Gear_phi_rel_ + (-1.0F * wRel);
	/* (325): self.'PI.P.y' := (self.'PI.P.k' * self.'PI.addP.y') */
	PI_P_y = PI_addP_y;
	/* (326): self.'PI.gainPI.u' := ((self.'PI.addPI.k1' * self.'PI.P.y') + (self.'PI.addPI.k2' * self.'PI.I.y')) */
	PI_gainPI_u = PI_P_y + PI_I_y;
	/* (327): self.'PI.gainPI.y' := (self.k_PI * self.'PI.gainPI.u') */
	PI_gainPI_y = k_PI * PI_gainPI_u;
	/* (328): self.'PI.limiter.u' := ((self.'PI.add_ff.k1' * self.'gear.y') + (self.'PI.add_ff.k2' * self.'PI.gainPI.y')) */
	PI_limiter_u = gear_y + PI_gainPI_y;
	/* (329): self.'PI.y' := (if (self.'PI.limiter.u' > self.tauM_max) then self.tauM_max elseif (self.'PI.limiter.u' < self.'PI.yMin') then self.'PI.yMin' else self.'PI.limiter.u') */
	PI_y = (PI_limiter_u > tauM_max) ? (tauM_max) : ((PI_limiter_u < PI_yMin) ? (PI_yMin) : (PI_limiter_u));
	/* (330): self.M_motor := (self.'gear1.k' * self.'PI.y') */
	/* Attention: assignment out of defined range: [-1000000.0, 1000000.0] is assigned a value from range:  (-oo, oo) */
	*M_motor = gear1_k * PI_y;
	/* (333): self.'derivative(filter.x[1])' := ((self.M_desired - self.'filter.x[1]') * self.'filter.w') */
	derivative_filter_x_1__ = (M_desired - filter_x_1_) * filter_w;
	/* (334): self.'PI.addSat.y' := ((self.'PI.addSat.k1' * self.'PI.limiter.u') + (self.'PI.addSat.k2' * self.'PI.y')) */
	PI_addSat_y = (-1.0F * PI_limiter_u) + PI_y;
	/* (335): self.'PI.addI.u3' := (self.'PI.gainTrack.k' * self.'PI.addSat.y') */
	PI_addI_u3 = PI_gainTrack_k * PI_addSat_y;
	/* (336): self.'PI.I.u' := (((self.'PI.addI.k1' * self.'derivative(approxPlant.driveline.Gear.phi_rel)') + (self.'PI.addI.k2' * self.wRel)) + (self.'PI.addI.k3' * self.'PI.addI.u3')) */
	PI_I_u = (derivative_approxPlant_driveline_Gear_phi_rel_ + (-1.0F * wRel)) + PI_addI_u3;
	/* (337): self.'derivative(PI.I.y)' := (self.'PI.I.k' * self.'PI.I.u') */
	derivative_PI_I_y_ = PI_I_k * PI_I_u;
	/* Adding saturation of limited variables when needed */
	/* Limitation needed for M_motor  with defined range: [-1000000.0, 1000000.0] and current value range (-oo, oo) */
	if (*M_motor < -1000000.0F) {
		*M_motor = -1000000.0F;
	} else if (*M_motor > 1000000.0F) {
		*M_motor = 1000000.0F;
	} else {
		/* limiting not needed */
	}
	/* Limitation needed for 'PI.I.y'  with defined range: [-10000.0, 10000.0] and current value range (-oo, oo) */
	if (PI_I_y < -10000.0F) {
		PI_I_y = -10000.0F;
	} else if (PI_I_y > 10000.0F) {
		PI_I_y = 10000.0F;
	} else {
		/* limiting not needed */
	}
}	/* DoStep*/

void Startup(unsigned int * signalVariable) {
	/* Initialization function only for state variables */
	/* Range: (-oo, oo) */
	float solution_buffer_for_x;
	/* (156): self.M_desired := 0.0 */
	M_desired = 0.0F;
	/* (157): self.wRel := 0.0 */
	wRel = 0.0F;
	/* (158): self.M_motor := 0.0 */
	M_motor = 0.0F;
	/* (159): self.'derivative(filter.x[1])' := 0.0 */
	derivative_filter_x_1__ = 0.0F;
	/* (160): self.'derivative(PI.I.y)' := 0.0 */
	derivative_PI_I_y_ = 0.0F;
	/* (161): self.'PI.addSat.y' := 0.0 */
	PI_addSat_y = 0.0F;
	/* (162): self.'PI.addI.u3' := 0.0 */
	PI_addI_u3 = 0.0F;
	/* (163): self.'PI.I.u' := 0.0 */
	PI_I_u = 0.0F;
	/* (195): () := Recalibrate() */
	Recalibrate();
	/* (198): self.'filter.x[2]' := self.'filter.x_start[2]' */
	filter_x_2_ = 0.0F;
	/* (199): self.'approxPlant.driveline.Gear.phi_rel' := 0.0 */
	approxPlant_driveline_Gear_phi_rel = 0.0F;
	/* (200): self.'filter.x[1]' := self.'filter.x_start[1]' */
	filter_x_1_ = 0.0F;
	/* (201): self.'PI.I.y' := self.'PI.xi_start' */
	PI_I_y = 0.0F;
	/* (204): self.'derivative(filter.x[2])' := ((self.'filter.x[1]' - self.'filter.x[2]') * self.'filter.w') */
	derivative_filter_x_2__ = (filter_x_1_ - filter_x_2_) * filter_w;
	/* (205): self.'derivative(approxPlant.torqueDist.flange.tau)' := -((self.k_accCor * self.'derivative(filter.x[2])')) */
	derivative_approxPlant_torqueDist_flange_tau_ = -(k_accCor * derivative_filter_x_2__);
	/* (206): self.'derivative(approxPlant.driveline.flange_b.tau)' := -((self.'derivative(filter.x[2])' + self.'derivative(approxPlant.torqueDist.flange.tau)')) */
	derivative_approxPlant_driveline_flange_b_tau_ = -(derivative_filter_x_2__ +
		 derivative_approxPlant_torqueDist_flange_tau_);
	/* (207): self.'approxPlant.torqueDist.flange.tau' := -((self.k_accCor * self.'filter.x[2]')) */
	approxPlant_torqueDist_flange_tau = -(k_accCor * filter_x_2_);
	/* (208): self.'approxPlant.driveline.flange_b.tau' := -((self.'filter.x[2]' + self.'approxPlant.torqueDist.flange.tau')) */
	approxPlant_driveline_flange_b_tau = -(filter_x_2_ + approxPlant_torqueDist_flange_tau);
	/* (209): self.'approxPlant.driveline.Gear.tau_c' := (self.c_res * (self.'approxPlant.driveline.Gear.phi_rel' - self.'approxPlant.driveline.Gear.phi_rel0')) */
	approxPlant_driveline_Gear_tau_c = c_res * (approxPlant_driveline_Gear_phi_rel - 0.0F);
	/* (210): self.'approxPlant.driveline.Gear.tau_d' := (self.'approxPlant.driveline.flange_b.tau' - self.'approxPlant.driveline.Gear.tau_c') */
	approxPlant_driveline_Gear_tau_d = approxPlant_driveline_flange_b_tau - approxPlant_driveline_Gear_tau_c;
	/* (211): 'solution_buffer.for.x' := (self.'approxPlant.driveline.Gear.tau_d' / self.d_res) */
	solution_buffer_for_x = approxPlant_driveline_Gear_tau_d / d_res;
	/* (212): if isNaN('solution_buffer.for.x') or isInfinite('solution_buffer.for.x')  */
	if (isnan(solution_buffer_for_x) || isinf(solution_buffer_for_x)) {
		/* (214): self.'derivative(approxPlant.driveline.Gear.phi_rel)' := 0.0 */
		derivative_approxPlant_driveline_Gear_phi_rel_ = 0.0F;
		/* (215): signal SOLVE_LINEAR_EQUATIONS_FAILED */
		*signalVariable = *signalVariable | 0x8U;
	} else {
		/* (218): self.'derivative(approxPlant.driveline.Gear.phi_rel)' := 'solution_buffer.for.x' */
		derivative_approxPlant_driveline_Gear_phi_rel_ = solution_buffer_for_x;
	}
	/* (220): self.'derivative(approxPlant.driveline.Gear.tau_c)' := (self.c_res * self.'derivative(approxPlant.driveline.Gear.phi_rel)') */
	derivative_approxPlant_driveline_Gear_tau_c_ = c_res * derivative_approxPlant_driveline_Gear_phi_rel_;
	/* (221): self.'derivative(approxPlant.driveline.Gear.tau_d)' := (self.'derivative(approxPlant.driveline.flange_b.tau)' - self.'derivative(approxPlant.driveline.Gear.tau_c)') */
	derivative_approxPlant_driveline_Gear_tau_d_ = derivative_approxPlant_driveline_flange_b_tau_ -
		 derivative_approxPlant_driveline_Gear_tau_c_;
	/* (222): 'solution_buffer.for.x' := (self.'derivative(approxPlant.driveline.Gear.tau_d)' / self.d_res) */
	solution_buffer_for_x = derivative_approxPlant_driveline_Gear_tau_d_ / d_res;
	/* (223): if isNaN('solution_buffer.for.x') or isInfinite('solution_buffer.for.x')  */
	if (isnan(solution_buffer_for_x) || isinf(solution_buffer_for_x)) {
		/* (225): self.'derivative(approxPlant.driveline.Gear.w_rel)' := 0.0 */
		derivative_approxPlant_driveline_Gear_w_rel_ = 0.0F;
		/* (226): signal SOLVE_LINEAR_EQUATIONS_FAILED */
		*signalVariable = *signalVariable | 0x8U;
	} else {
		/* (229): self.'derivative(approxPlant.driveline.Gear.w_rel)' := 'solution_buffer.for.x' */
		derivative_approxPlant_driveline_Gear_w_rel_ = solution_buffer_for_x;
	}
	/* (231): self.'derivative(approxPlant.driveline.inertiaDrivelineIn.w)' := -((self.gearRatio * self.'derivative(approxPlant.driveline.Gear.w_rel)')) */
	derivative_approxPlant_driveline_inertiaDrivelineIn_w_ = -(gearRatio * derivative_approxPlant_driveline_Gear_w_rel_);
	/* (232): 'solution_buffer.for.x' := (self.'approxPlant.driveline.flange_b.tau' / self.gearRatio) */
	solution_buffer_for_x = approxPlant_driveline_flange_b_tau / gearRatio;
	/* (233): if isNaN('solution_buffer.for.x') or isInfinite('solution_buffer.for.x')  */
	if (isnan(solution_buffer_for_x) || isinf(solution_buffer_for_x)) {
		/* (235): self.'approxPlant.driveline.inertiaDrivelineIn.flange_b.tau' := 0.0 */
		approxPlant_driveline_inertiaDrivelineIn_flange_b_tau = 0.0F;
		/* (236): signal SOLVE_LINEAR_EQUATIONS_FAILED */
		*signalVariable = *signalVariable | 0x8U;
	} else {
		/* (239): self.'approxPlant.driveline.inertiaDrivelineIn.flange_b.tau' := 'solution_buffer.for.x' */
		approxPlant_driveline_inertiaDrivelineIn_flange_b_tau = solution_buffer_for_x;
	}
	/* (241): self.'gear.u' := ((self.'approxPlant.driveline.J_M' * self.'derivative(approxPlant.driveline.inertiaDrivelineIn.w)') - self.'approxPlant.driveline.inertiaDrivelineIn.flange_b.tau') */
	gear_u = (approxPlant_driveline_J_M * derivative_approxPlant_driveline_inertiaDrivelineIn_w_) -
		 approxPlant_driveline_inertiaDrivelineIn_flange_b_tau;
	/* (242): self.'gear.y' := (self.gearRatio * self.'gear.u') */
	gear_y = gearRatio * gear_u;
	/* (243): self.'PI.addP.y' := ((self.'PI.wp' * self.'derivative(approxPlant.driveline.Gear.phi_rel)') + (self.'PI.addP.k2' * self.wRel)) */
	PI_addP_y = derivative_approxPlant_driveline_Gear_phi_rel_ + (-1.0F * wRel);
	/* (244): self.'PI.P.y' := (self.'PI.P.k' * self.'PI.addP.y') */
	PI_P_y = PI_addP_y;
	/* (245): self.'PI.gainPI.u' := ((self.'PI.addPI.k1' * self.'PI.P.y') + (self.'PI.addPI.k2' * self.'PI.I.y')) */
	PI_gainPI_u = PI_P_y + PI_I_y;
	/* (246): self.'PI.gainPI.y' := (self.k_PI * self.'PI.gainPI.u') */
	PI_gainPI_y = k_PI * PI_gainPI_u;
	/* (247): self.'PI.limiter.u' := ((self.'PI.add_ff.k1' * self.'gear.y') + (self.'PI.add_ff.k2' * self.'PI.gainPI.y')) */
	PI_limiter_u = gear_y + PI_gainPI_y;
	/* (248): self.'PI.y' := (if (self.'PI.limiter.u' > self.tauM_max) then self.tauM_max elseif (self.'PI.limiter.u' < self.'PI.yMin') then self.'PI.yMin' else self.'PI.limiter.u') */
	PI_y = (PI_limiter_u > tauM_max) ? (tauM_max) : ((PI_limiter_u < PI_yMin) ? (PI_yMin) : (PI_limiter_u));
	/* Adding saturation of limited variables when needed */
	/* No limitation needed for M_desired with range: [-1000000.0, 1000000.0] and current value range: [0.0, 0.0] */
	/* No limitation needed for wRel with range: [-10000.0, 10000.0] and current value range: [0.0, 0.0] */
	/* No limitation needed for M_motor with range: [-1000000.0, 1000000.0] and current value range: [0.0, 0.0] */
	/* No limitation needed for Ni_PI with range: [1.0E-13, oo) and current value range: [1.0E-13, oo) */
	/* No limitation needed for Ti_PI with range: [1.0E-60, oo) and current value range: [1.0E-60, oo) */
	/* No limitation needed for c_res with range: [0.0, oo) and current value range: [0.0, oo) */
	/* No limitation needed for d_res with range: [0.0, oo) and current value range: [0.0, oo) */
	/* No limitation needed for 'PI.I.y' with range: [-10000.0, 10000.0] and current value range: [0.0, 0.0] */
}	/* Startup*/
