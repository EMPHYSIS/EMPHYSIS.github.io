#ifndef M04_A_H
#define M04_A_H
/**
 * @warning   AUTOMATICALLY GENERATED FILE! DO NOT EDIT!
 * @warning   THIS IS A NIGHTLY TOOL BUILD! DO NOT USE FOR PRODUCTION!
 * 
 * @source    'eFMI_TestCases.M04_DrivetrainTorqueControl.Controllers.Controller'
 * 
 * @tool      SCODE-CONGRA (EFMI)  Build Id: 0000
 * 
 * @date      3/15/2021 08:20:42 AM
 * 
 **/
#include <math.h>
extern unsigned int signalVariable;
/* Range: [-1000000.0, 1000000.0] */
extern double M_desired;
/* Range: [-10000.0, 10000.0] */
extern double wRel;
/* Range: [-1000000.0, 1000000.0] */
extern double M_motor;
/* Range: (-oo, oo) */
extern double J_M;
/* Range: [1.0E-13, oo) */
extern double Ni_PI;
/* Range: [1.0E-60, oo) */
extern double Ti_PI;
/* Range: [0.0, oo) */
extern double c_res;
/* Range: [0.0, oo) */
extern double d_res;
/* Range: (-oo, oo) */
extern double f_cut;
/* Range: (-oo, oo) */
extern double gearRatio;
/* Range: (-oo, oo) */
extern double k_PI;
/* Range: (-oo, oo) */
extern double k_accCor;
/* Range: (-oo, oo) */
extern double tauM_max;

void Recalibrate(void);

void DoStep(double M_desired, double wRel, double * M_motor, unsigned int * signalVariable);

void Startup(unsigned int * signalVariable);

#endif  /* M04_A_H */
